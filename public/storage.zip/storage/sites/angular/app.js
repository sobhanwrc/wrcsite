var appWrc = angular.module('appWrc',['appRoutes', 'oitozero.ngSweetAlert', 'ngSanitize']);

appWrc.directive('myNavbar',function(){
	return {
		restrict: 'E',
		templateUrl: 'templates/navbar.html',
		scope: true
	};
});

appWrc.controller('MainController',function($scope,$http,SweetAlert){
	$scope.doContact = function(valid) {
		if(valid) {
			$scope.isDisabled = true;

			$http.post('/api/contact-us-submit', {
			data:$scope.contact
		}).then(function(response){
			if(response.data.code == '100'){
				SweetAlert.swal({   
					title: "Thank You",   
					text: "Submit successfully!",   
					type: "success",     
					confirmButtonColor: "#DD6B55",   
					confirmButtonText: "OK"
				},  function(){ 
					$scope.isDisabled = false; 
					window.location.reload();
					
				});
			}
		}).catch(function(reason){
			
		});
		}
	};

	$scope.company_details = function() {
		$http.get('/api/wrc-website-details').then(function(response){

			$scope.contact_details = response.data.contact_details;
		
		}).catch(function(reason){

		});
	}
});